from django.contrib import admin
from .models import Product
# Register your models here.


class ProductAdmin(admin.ModelAdmin):
    list_display = ("id","name", "details", "price")
    list_filter = ("category", "date_created")


admin.site.register(Product, ProductAdmin)
