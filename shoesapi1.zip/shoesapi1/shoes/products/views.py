
from django.shortcuts import render
from django.http import Http404
from rest_framework.views import APIView
from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework import status
from django.http import JsonResponse
from django.core import serializers
from django.conf import settings
from .models import Product
import json


@api_view(["GET"])
def products_view():
    try:
        # products_list = Product.objects.all()
        data = {"key1":"value1"}
        return JsonResponse(data,safe=False)
    except ValueError as e:
        return Response(e.args[0],status.HTTP_400_BAD_REQUEST)


# @api_view(["POST"])
# def products_details_view(request):
#     try:
#         data=json.loads(request.body)
#
#         return JsonResponse(data,safe=False)
#     except ValueError as e:
#         return Response(e.args[0],status.HTTP_400_BAD_REQUEST)
